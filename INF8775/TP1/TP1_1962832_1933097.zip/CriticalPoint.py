class CriticalPoint:
    """_summary_
    Classe simple permettant de representer des points critiques. Un point critique possède un x (une position) et une hauteur.
    """
    def __init__(self, x, height):
        self.x = x
        self.height = height