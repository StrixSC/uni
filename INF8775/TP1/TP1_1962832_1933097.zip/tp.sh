#!/bin/sh
./main.py "$@"