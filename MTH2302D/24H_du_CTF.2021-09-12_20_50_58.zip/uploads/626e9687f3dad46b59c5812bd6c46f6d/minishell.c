#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUF_SIZE 40
#define DELIM " "

typedef struct Variable {
    char name[BUF_SIZE];
    char value[BUF_SIZE];
    struct Variable *next;
}Variable;

Variable *Head = NULL;

void list_files() {
    system("ls");
}

void print_user() {
    system("whoami");
}

Variable* is_defined(char *variable) {
    Variable *curr = Head;
    if (variable != NULL) {
        while (curr != NULL) {
            if (strncmp(variable, curr->name, BUF_SIZE) == 0) {
                return curr;
            }
            curr = curr->next;
        }
    }
    return NULL;
}

void overwrite_variable(Variable* var, char* value) {
    for (int i=0; i<BUF_SIZE; i++) {
        var->value[i] = value[i];
        if (value[i] == '\x00')
            break;
    }
}

void modify_variable(Variable* var, char* value) {
    char choice[8];
    printf("Do you want to (o)verwrite or (a)ppend? ");
    fgets(choice, BUF_SIZE, stdin);
    if (choice[0] == 'o')
        overwrite_variable(var, value);
    else if (choice[0] == 'a') {
        size_t size_left = BUF_SIZE - strlen(var->value) - 1;
        strncat(var->value, value, size_left);
    }
}

void define_variable() {
    char* name = strtok(NULL, DELIM);
    char* value = strtok(NULL, DELIM);
    if (name == NULL || value == NULL) {
        puts("Invalid syntax");
        return;
    }
    Variable *var;
    if (var = is_defined(name)) {
        modify_variable(var, value);
    }
    else {
        var = (Variable*)malloc(sizeof(Variable));
        strncpy(var->name, name, BUF_SIZE);
        strncpy(var->value, value, BUF_SIZE);
        var->next = Head;
        Head = var;
    }
}

void print_variable() {
    Variable *var;
    char *name = strtok(NULL, DELIM);
    if (name != NULL && (var = is_defined(name)))
        printf("%s\n", var->value);
    else
        puts("Undefined variable");
}

void print_help() {
    puts("list: list files");
    puts("user: print current user");
    puts("define <variable> <value>: set variable");
    puts("echo <variable>: print variable");
    puts("help: print this message");
    puts("exit: quit the application");
}

void cleanup() {
    Variable *curr;
    while (Head != NULL) {
        curr = Head->next;
        free(Head);
        Head = curr;
    }
}

int main(int argc, char** argv) {
    char buffer[40];
    char *pos, *token;

    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);

    puts("mini-shell v0.4");
    puts("type 'help' for help");
    while(1) {
        printf("> ");
        fgets(buffer, BUF_SIZE, stdin);
        // Strip newline
        if ((pos=strchr(buffer, '\n')) != NULL)
            *pos = '\0';
        token = strtok(buffer, " ");
        if (strncmp(token, "list", BUF_SIZE) == 0)
            list_files();
        else if (strncmp(token, "user", BUF_SIZE) == 0)
            print_user();
        else if (strncmp(token, "define", BUF_SIZE) == 0)
            define_variable();
        else if (strncmp(token, "echo", BUF_SIZE) == 0)
            print_variable();
        else if (strncmp(token, "help", BUF_SIZE) == 0)
            print_help();
        else if (strncmp(token, "exit", BUF_SIZE) == 0)
            break;
        else {
            puts("Invalid choice");
        }
    }
    cleanup();
    return 0;
}
