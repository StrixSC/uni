#include <stdio.h>
#include <stdlib.h>

void win() {
	puts("Congratulation!");
	fflush(stdout);

	system("/bin/sh");
}

void get_input() {
	char input[0x100];
	
	puts("Please input something:");
	fflush(stdout);

	gets(input);
}

int main() {
	get_input();
	
	puts("Better luck next time!");
	fflush(stdout);

	return 0;
}
