#![feature(proc_macro_hygiene, decl_macro)]

#[macro_use]
extern crate rocket;

extern crate aes;
extern crate base64;
extern crate cipher_crypt;
extern crate ctr;
extern crate rand;


use ctr::stream_cipher::{ NewStreamCipher, SyncStreamCipher, generic_array::GenericArray};
use rand::{ RngCore, rngs::OsRng };
use cipher_crypt::{ Caesar, Cipher };
use rocket::State;
use rocket::response::{ NamedFile, Redirect};
use std::path::{Path, PathBuf};

pub struct EncryptionData {
    pub key: Vec<u8>,
    pub nonce: Vec<u8>,
    pub flag: String,
}

#[get("/rot/<rot>")]
fn route_encrypt(rot: usize, state: State<EncryptionData>) -> Result<String, &str>  {
    if rot == 0 || rot > 26  {
        return Ok("Invalid ROT!".to_string())
    }

    // ROTx and Caesar are different names of the same thing.
    let cipher = Caesar::new(rot);
    let rotted_flag = cipher.encrypt(&state.flag)?;

    let ciphertext = encrypt(&rotted_flag.as_bytes(),
        &state.key,
        &state.nonce);

    Ok(base64::encode(&ciphertext))
}

#[get("/")]
fn index() -> Redirect {
    Redirect::to(uri!(static_serve: "index.html"))
}

#[get("/<file..>", rank = 10)]
fn static_serve(file: Option<PathBuf>) -> Option<NamedFile> {
    let file = match file {
        None => PathBuf::from("index.html"),
        Some(f) => f,
    };
    NamedFile::open(Path::new("ui/").join(file)).ok()
}

pub fn encrypt(plaintext: &[u8], key: &[u8], nonce: &[u8]) -> Vec<u8>{
    let mut ciphertext = Vec::from(plaintext);
    let mut cipher = ctr::Ctr128::<aes::Aes128>::new(
        GenericArray::from_slice(&key),
        GenericArray::from_slice(&nonce));
    cipher.apply_keystream(&mut ciphertext);
    ciphertext
}

fn main() {

    let mut key = vec![0u8; 16];
    let mut nonce = vec![0u8; 16];
    OsRng.fill_bytes(&mut key);
    OsRng.fill_bytes(&mut nonce);

    let flag = include_str!("flag.txt").to_string();

    rocket::ignite()
        .manage(EncryptionData {
            key,
            nonce,
            flag
        })
        .mount("/api", routes![route_encrypt])
        .mount("/", routes![index, static_serve])
        .launch();
}
