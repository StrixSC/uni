#!/usr/local/bin/python3
# Thanks to http://patorjk.com/software/taag/ for the ASCII Art

ART = """
   _     _     _     _     _     _     _     _     _     _     _     _     _     _   
  (c).-.(c)   (c).-.(c)   (c).-.(c)   (c).-.(c)   (c).-.(c)   (c).-.(c)   (c).-.(c)  
   / ._. \     / ._. \     / ._. \     / ._. \     / ._. \     / ._. \     / ._. \   
 __\( Y )/__ __\( Y )/__ __\( Y )/__ __\( Y )/__ __\( Y )/__ __\( Y )/__ __\( Y )/__ 
(_.-/'-'\-._|_.-/'-'\-._|_.-/'-'\-._|_.-/'-'\-._|_.-/'-'\-._|_.-/'-'\-._|_.-/'-'\-._)
   || P ||     || O ||     || L ||     || Y ||     || C ||     || T ||     || F ||   
 _.' `-' '._ _.' `-' '._ _.' `-' '._ _.' `-' '._ _.' `-' '._ _.' `-' '._ _.' `-' '._ 
(.-./`-'\.-.|.-./`-'\.-.|.-./`-'\.-.|.-./`-'\.-.|.-./`-'\.-.|.-./`-'\.-.|.-./`-'\.-.)
 `-'     `-' `-'     `-' `-'     `-' `-'     `-' `-'     `-' `-'     `-' `-'     `-' 
"""

WELCOME = """
Welcome to the workshop!
You can now make any flag you have ever wanted!
All our flag parts are based on our secret ingredient, the Master Flag!

Flag-O-Matic will be here to assist you.

"""

import sys
import os
import secrets
import socketserver
import socket

class FlagOMatic(socketserver.BaseRequestHandler):
	def setup(fom):
		fom.thinking_time = 45
		fom.parts = {
			"prefix": FlagPart("NotRealCTF", secrets.randbelow(31337)+1337),
			"joiner": FlagPart("_", secrets.randbelow(31337)+1337),
			"left": FlagPart("{", secrets.randbelow(31337)+1337),
			"right": FlagPart("}", secrets.randbelow(31337)+1337),
		}
		fom.chatTemplate = '[Flag-O-Matic]: {}\n'
		fom.disp = '{:>20}{:>20}{:>20}\n'

	def displayAvailableParts(fom):
		fom.say('Here are the available parts today.\n')
		fom.print(fom.disp.format('Part Name', 'Part', 'Quantity'))
		fom.print('-'*60+"\n")
		for i, p in fom.parts.items():
			fom.print(fom.disp.format('{'+i+'}', p.display, p.quantity))
		fom.print('-'*60+"\n\n")

	def assembleFlag(fom, template):
		try:
			result = template.format(**fom.parts)
			fom.print('\n')
			fom.say('Here is your flag!')
			fom.print(result+'\n')
		except KeyError as x:
			fom.say('Please, only use currently available parts.\n')
		except Exception as x:
			fom.say('Hey, what did you do?\n')
			fom.print('[Error]: ' + str(x))

	def say(fom, message):
		fom.print(fom.chatTemplate.format(message))

	def print(fom, message):
		fom.request.sendall(message.encode())

	def handle(fom):
		fom.request.settimeout(fom.thinking_time)
		try:
			fom.print(ART)
			fom.print(WELCOME)

			fom.displayAvailableParts()

			fom.say('Here is a template to get you started.')
			fom.print('Template Example: {prefix}{left}ThisIsAnExample{right}\n\n')

			fom.say('You have {} seconds to give us your flag template'.format(fom.thinking_time))
			fom.print('Your template: ')

			inp = fom.request.recv(1024).strip().decode()
			fom.assembleFlag(inp)

		except socket.timeout as err:
			fom.say("\n\nYour time has elapsed.")
		except BrokenPipeError as err:
			print("Broken pipe")
		except Exception as err:
			print("Some exception happened.")
			print(err)

def secretIngredient():
	masterFlag = '''
	//////////////////////////////////////////////////
	//////////////////////////////////////////////////
	//////////////////////////////////////////////////
	////////////////////TOP SECRET////////////////////
	//////////////////////////////////////////////////
	//////////////////////////////////////////////////
	//////////////////////////////////////////////////
	'''
	return masterFlag

class FlagPart():
	def __init__(self, display, quantity):
		self.display = display
		self.quantity = quantity

	def __str__(self):
		return self.display

class ChallengeServer(socketserver.ThreadingTCPServer):
	allow_reuse_address = True

if __name__ == "__main__":
	address = ("0.0.0.0", 1337)

	with ChallengeServer(address, FlagOMatic) as server:
		while True:
			server.handle_request()
